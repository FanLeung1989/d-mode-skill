# D Mode 四書查用路由

先問觀眾需要知道／感到甚麼，再檢查人物目標、空間及已批准限制，最後選技術；不從機身或漂亮運鏡倒推故事。

1. 以 [敘事功能](director-catalog/index-narrative_functions.md) 或 [情緒](director-catalog/index-emotions.md) 找候選。
2. 用 [機制大類](director-catalog/index-mechanism_families.md) 與 [技術標籤](director-catalog/index-technique_tags.md) 篩選可行操作。
3. 在 [ID總索引](director-catalog/index-all.md) 開對應章檔，讀來源釋義、條件、限制、變體及父子關係。每個被採用的方法都要讀卡，不只看標題。
4. 必要時比較 [跨書相關機制](director-relations.md)，提供2–3種實質不同選項及原因。
5. [舊K卡映射](director-legacy-map.md)只供追溯；[來源覆蓋](source-coverage.md)保留缺頁與讀圖限制。

分類可複選，情緒標籤不是觀眾反應定律。原書主法、編者拆出的子法、一般原則、案例組合、術語條目與缺頁占位分開，不以記錄數宣稱互不重疊的原創方法數。B3-M068缺正文，禁止作已掌握方法推薦。AI延伸全部未經生成實測。
