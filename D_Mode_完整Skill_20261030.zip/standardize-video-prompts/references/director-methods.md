# 導演方法庫入口

首批16卡已由四書逐章分類目錄取代；舊ID與更正見 [director-legacy-map.md](director-legacy-map.md)。不要沿用早期摘要作唯一內容。

- [全部ID及分章連結](director-catalog/index-all.md)
- [機制大類](director-catalog/index-mechanism_families.md)
- [敘事功能](director-catalog/index-narrative_functions.md)
- [情緒](director-catalog/index-emotions.md)
- [技術操作](director-catalog/index-technique_tags.md)
- [跨書相似／不同機制](director-relations.md)

只讀本次需要的章檔。程式化查詢可讀 director-catalog/catalog.json，完整保留每筆原始來源記錄、父條及分類；所有來源查核限制見 source-coverage.md。
